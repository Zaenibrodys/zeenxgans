const listmenu = (prefix) => { 
	return `                 

╔══✪〘 OWNER 〙✪══
║
╠➥ *${prefix}block 62858xxxxx*
╠➥ *${prefix}unblock 62858xxxxx*
╠➥ *${prefix}promote @tagmember*
╠➥ *${prefix}demote @tagadmin*
╠➥ *${prefix}bc*
╠➥ *${prefix}leave*
╠➥  *${prefix}bc2*
╠➥  *${prefix}leave*
╠➥  *${prefix}clearall*
╠➥  *${prefix}clone*
╠➥  *${prefix}hidetag*
╠➥  *${prefix}hidetag2*
╠➥  *${prefix}setprefix*
╠➥  *${prefix}unban*
╠➥  *${prefix}ban*
╠➥ *${prefix}runtime*
╠➥ *${prefix}turnoff*
╠➥  *${prefix}getses*
║
╠══✪〘 ADMIN 〙✪══
║
╠➥ *${prefix}ban @tagmember*
╠➥ *${prefix}unban @tagmember*
╠➥ *${prefix}spamcall [81273xxxx]*
╠➥ *${prefix}kickall*
╠➥ *${prefix}leave*
╠➥ *${prefix}promote*
╠➥ *${prefix}demote*
╠➥ *${prefix}delete*
╠➥ *${prefix}add 62813xxxxx*
╠➥ *${prefix}kickall*
╠➥ *${prefix}tagall*
╠➥  *${prefix}otagall*
╠➥  *${prefix}otagall2*
╠➥  *${prefix}tagall*
╠➥  *${prefix}setdesc*
╠➥  *${prefix}setname*
╠➥  *${prefix}kick* [tag]
╠➥  *${prefix}add* [628xxx]
╠➥  *${prefix}promote* [tag]
╠➥  *${prefix}demote* [tag]
╠➥  *${prefix}group* [buka]
╠➥  *${prefix}group* [tutup]
╠➥  *${prefix}linkgc*
╠➥  *${prefix}setpp* [foto kau]
╠➥  *${prefix}groupinfo*
╠➥  *${prefix}tagme*
╠➥  *${prefix}nsfw* [1/0]
╠➥  *${prefix}anime* [1/0]
╠➥  *${prefix}simih* [1/0]
╠➥  *${prefix}welcome* [1/0]
╠➥  *${prefix}edotensei*
╠➥  *${prefix}listadmins*
╠➥  *${prefix}ping*
╠══✪〘 FUN 〙✪══ [Maintenance!!]*
║
╠➥ *${prefix}tebakgambar*
╠➥ *${prefix}caklontong*
╠➥ *${prefix}family100*
╠➥ *${prefix}game*
╠➥ *${prefix}truth*
╠➥ *${prefix}dare*
╠➥ *${prefix}quotes*
╠➥ *${prefix}hilih*
╠➥ *${prefix}alay* [text]
╠➥ *${prefix}simi* [text]
╠➥ *${prefix}bucin*
╠➥ *${prefix}gtts* [text]
╠➥ *${prefix}tts*
║
╠══✪〘 KERANG 〙✪══
║
╠➥ *${prefix}apakah [optional]*
╠➥ *${prefix}rate [optional]*
╠➥ *${prefix}bisakah [optional]*
╠➥ *${prefix}kapankah [optional]*
╠➥ *${prefix}gantengcek*
╠➥ *${prefix}toxic*
╠➥ *${prefix}cantikcek*
╠➥ *${prefix}persengay*
║
╠══✪〘 MAKER 〙✪══ *[Maintenance!!]*
║
╠➥ *${prefix}tahta* [iki]
╠➥ *${prefix}pronlogo* [text|text]
╠➥ *${prefix}snow* [text|text]
╠➥ *${prefix}marvelogo* [text|text]
╠➥ *${prefix}text3d* [text]
╠➥ *${prefix}ninjalogo* [text|text]
╠➥ *${prefix}wolflogo* [text|text]
╠➥ *${prefix}lionlogo* [text|text]
╠➥ *${prefix}textscreen* [text
╠➥ *${prefix}rtext* [text]
╠➥ *${prefix}thunder* [text]
╠➥ *${prefix}stiltext* [text|text]
╠➥ *${prefix}party* [text]
╠➥ *${prefix}galaxtext* [text]
╠➥ *${prefix}lovemake* [text]
╠➥ *${prefix}walpaperhd* [text]
╠➥ *${prefix}watercolor* [text]
╠➥ *${prefix}quotemaker* [tx|tx|random]
╠➥ *${prefix}water* [text]
╠➥ *${prefix}epep* [text]
╠➥ *${prefix}glitch* [text]
╠➥ *${prefix}jokerlogo [teks]*
║
╠══✪〘 MEDIA 〙✪══
║
╠➥ *${prefix}yt* [link]
╠➥ *${prefix}tiktok* [link]
╠➥ *${prefix}ytsearch* [yt search]
╠➥ *${prefix}lirik* [judul lagu]
╠➥ *${prefix}chord* [judul lagu]
╠➥ *${prefix}igstalk* [Rizky]
╠➥ *${prefix}wikien* [love]
╠➥ *${prefix}tiktokstalk* [username]
╠➥ *${prefix}url2img* [link]
╠➥ *${prefix}fototiktok* [username]
╠➥ *${prefix}map* [kota]
╠➥ *${prefix}kbbi* [kamus]
╠➥ *${prefix}brainly* [tau sendiri kan]
╠➥ *${prefix}infoghitub* 
╠➥ *${prefix}infocuaca* [kota]
╠➥ *${prefix}infogempa*
╠➥ *${prefix}artinama [nama]*
╠➥ *${prefix}covid [negara]*
╠➥ *${prefix}nulis [teks]*
╠➥ *${prefix}sandwriting [teks]*
╠➥ *${prefix}quotemaker [|teks|author|theme]*
╠➥ *${prefix}resepmasakan [optional]*
╠➥ *${prefix}tts [kode bhs] [teks]*
╠➥ *${prefix}igstalk [@username]*
╠➥ *${prefix}tiktokstalk [@username]*
╠➥ *${prefix}wiki [query]*
╠➥ *${prefix}qrcode [optional]*
╠➥ *${prefix}map [optional]*
╠➥ *${prefix}textmaker [teks1|teks2]*
╠➥ *${prefix}ssweb [linkWeb]*
╠➥ *${prefix}shorturl [linkWeb]*
╠➥ *${prefix}animesaran*
╠➥ *${prefix}animesaran2*
║
╠══✪〘 VIP USER 〙✪══
║
╠➥ *${prefix}ytmp4 [link]*
╠➥ *${prefix}ytmp3 [link]*
╠➥ *${prefix}hidetag2*
╠➥ *${prefix}joox [lagu]*
╠➥ *${prefix}setprefix*
╠➥ *${prefix}tomp3 [replay video]*
╠➥  *${prefix}randomanime*
╠➥  *${prefix}randomhentai*
╠➥  *${prefix}nsfwloli*
╠➥  *${prefix}nsfwblowjob*
╠➥  *${prefix}nsfwneko*
╠➥  *${prefix}nsfwtrap*
╠➥  *${prefix}indohot*
╠➥  *${prefix}otagall2*
╠➥  *${prefix}otagall3*
╠➥  *${prefix}hidetag5*
║
╠══✪〘 NSFW 〙✪══
║
╠➥ *${prefix}randomhentai*
╠➥ *${prefix}hentai*
╠➥ *${prefix}nsfwblowjob*
╠➥ *${prefix}nsfwtrap*
╠➥ *${prefix}nsfwneko*
╠➥ *${prefix}loli*
╠➥ *${prefix}nsfwloli*
╠➥ *${prefix}bokep*
╠➥ *${prefix}kodenuklir2*
╠➥ *${prefix}randomanime*
╠➥ *${prefix}cry*
╠➥ *${prefix}kiss*
╠➥ *${prefix}randomhug*
╠➥ *${prefix}nekonime*
╠➥ *${prefix}waifu*
╠➥ *${prefix}waifu2*
╠➥ *${prefix}kodenuklir*
╠➥ *${prefix}nekopoi*
║
╠══✪〘 OTHER 〙✪══
║
╠➥ *${prefix}sticker*
╠➥ *${prefix}stickergif*
╠➥ *${prefix}ttp [teks]*
╠➥ *${prefix}toimg [replay sticker]*
╠➥ *${prefix}neko*
╠➥ *${prefix}pokemon*
╠➥ *${prefix}inu*
╠➥ *${prefix}infoGempa*
╠➥ *${prefix}quotes*
╠➥ *${prefix}dadu*
╠➥ *${prefix}quotes*
╠➥ *${prefix}thunder [teks]*
╠➥ *${prefix}nulis [teks]*
╠➥ *${prefix}ocr [gambar]*
╠➥ *${prefix}meme*
╠➥ *${prefix}memindo*
╠➥ *${prefix}testime*
╠➥ *${prefix}ttp [teks]*
╠➥ *${prefix}hobby*
╠➥ *${prefix}beritahoax*
╠➥ *${prefix}watak*
╠➥ *${prefix}jsholat [daerah]*
╠➥ *${prefix}report*
╠➥ *${prefix}hilih [teks]*
╠➥ *${prefix}cekjodoh* [nama]
╠➥ *${prefix}artinama* [rizky]
╠➥ *${prefix}listsurah*
╠➥ *${prefix}zodiak [zodiak kamu]*
╠➥ *${prefix}listzodiak*
║
╠═══✪〘 ANIMALS 〙✪══
║
╠➥ *${prefix}unta*
╠➥ *${prefix}elang*
╠➥ *${prefix}anjing*
╠➥ *${prefix}randomcat*
║
╚═ Ketik *${prefix}info* untuk melihat list informasi tentang bot
       Ketik *${prefix}owner* untuk melihat kontak owner
         Mau donasi? 082178381441(Gopay)
         Jika tidak ingin donasi bantu Follow Ig aja kak 
         _instagram.com/pinesstore_
    _*ZEEN BOT © 2021*_`
}
exports.listmenu = listmenu